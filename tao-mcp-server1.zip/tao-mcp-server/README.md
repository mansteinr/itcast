# TAO MCP Server

TAO Agent 管理后台 MCP Server，将 [TrendyAgentOps](http://192.168.36.118:8888/) 管理后台 API 封装为 109 个 MCP Tool，支持 **stdio** 和 **streamable-http** 双传输模式。

## 架构

```
MCP Client (Claude Desktop / CodeBuddy / Cursor)
        │
        ├── stdio 模式 ────→ StdioServerTransport ──→ McpServer (per-session)
        │
        └── HTTP 模式 ────→ Express (:9988) ──→ StreamableHTTPServerTransport
                                                         │
                                                    AsyncLocalStorage
                                                    (认证透传：Bearer + Cookie)
                                                         │
                                                    apiRequest() ──→ 后端 API
```

### 设计亮点

- **Per-session 隔离**：每个 MCP Client 连接创建独立 `McpServer` 实例，避免状态串扰
- **认证透传**：通过 `AsyncLocalStorage` 将 MCP Client 的 Bearer Token / Session Cookie 原封不动转发至后端 API，无需在服务端硬编码凭据
- **双模式运行**：本地开发用 stdio，服务器部署用 streamable-http，一套代码两处运行

## 快速开始

### 1. 环境准备

```bash
# Node.js >= 18
node -v
```

### 2. 安装依赖

```bash
cd tao-mcp-server
npm install
```

### 3. 配置环境变量

```bash
cp .env.example .env
```

编辑 `.env`：

```env
# 后端 API 地址（必填）
API_BASE_URL=http://192.168.36.118:8888/

# 传输模式：不设置 = stdio，设置为 streamable-http = HTTP
# MCP_TRANSPORT=streamable-http

# HTTP 监听端口（仅 HTTP 模式生效）
MCP_PORT=9988
```

### 4. 启动

```bash
# stdio 模式（本地 Claude Desktop / CodeBuddy 调用）
npm start

# HTTP 模式（远程部署）
npm run start:http

# 开发模式（文件变更自动重启）
npm run dev
```

## 部署到服务器

### 方式一：start.sh（推荐）

```bash
# 一键启动（HTTP 模式，默认端口 9988）
./start.sh http

# 指定端口
./start.sh http 4567
```

脚本自动完成：依赖安装 → 环境变量加载 → nohup 后台启动 → 健康检查验证。

日志输出至 `logs/server.log`。

### 方式二：PM2

```bash
npm install -g pm2
pm2 start ecosystem.config.cjs
pm2 save
```

### 健康检查

```bash
curl http://localhost:9988/health
# {"status":"ok","tools":109}
```

## 配置 MCP Client

### Claude Desktop

```json
{
  "mcpServers": {
    "tao-mcp-server": {
      "command": "npx",
      "args": ["tsx", "/path/to/tao-mcp-server/src/index.ts"],
      "env": {
        "API_BASE_URL": "http://192.168.36.118:8888/"
      }
    }
  }
}
```

### CodeBuddy（远程 HTTP）

```json
{
  "mcpServers": {
    "tao-mcp-server": {
      "transport": "streamable-http",
      "url": "http://<server-ip>:9988/mcp"
    }
  }
}
```

### 认证配置

MCP Client 调用时，通过请求头透传认证信息：

| 方式 | 请求头 | 说明 |
|------|--------|------|
| Bearer Token | `Authorization: Bearer <token>` | 标准 Bearer 鉴权 |
| API Key | `x-api-key: <key>` | 自定义 Header |
| Session Cookie | `x-session-cookie: <cookie>` 或 `Cookie: <cookie>` | 后端实际鉴权方式 |

Server 端从请求头提取认证信息后，通过 `AsyncLocalStorage` 注入到下游 `apiRequest()`，无需在 `.env` 中硬编码凭据。

## Tool 列表（109 个）

### 路由策略（8）

| Tool | 说明 |
|------|------|
| `create_routing_strategy` | 创建路由规则 |
| `update_routing_strategy` | 更新路由规则 |
| `delete_routing_strategy` | 删除路由规则 |
| `get_routing_strategy` | 获取路由规则详情 |
| `get_routing_strategy_page` | 获取路由规则分页列表 |
| `enable_routing_strategy` | 启用/禁用路由规则 |
| `get_base_url_config` | 获取 BaseURL 配置 |
| `update_base_url_config` | 设置 BaseURL 配置 |

### 路由插件（4）

| Tool | 说明 |
|------|------|
| `get_plugin_list` | 获取路由的所有插件列表 |
| `toggle_plugin` | 启用/停用插件 |
| `get_plugin_config` | 获取插件配置详情 |
| `save_plugin_config` | 保存插件配置 |

### 大模型供应商（7）

| Tool | 说明 |
|------|------|
| `create_provider` | 创建供应商 |
| `update_provider` | 更新供应商 |
| `delete_provider` | 删除供应商 |
| `get_provider` | 获取供应商 |
| `get_provider_page` | 获取供应商分页列表 |
| `get_provider_models` | 获取供应商关联的模型信息 |
| `init_smart_router_provider_routes` | 初始化供应商智能路由分发层路由 |

### 大模型管理（10）

| Tool | 说明 |
|------|------|
| `get_llm_model` | 获取模型详情 |
| `get_llm_model_page` | 获取模型分页列表 |
| `update_rate` | 设置模型费率 |
| `create_public_model` | 添加公共模型 |
| `delete_public_model` | 删除公共模型 |
| `create_private_model` | 添加本地模型 |
| `get_model_add_progress` | 获取本地模型添加进度 |
| `start_private_model` | 启动本地模型 |
| `stop_private_model` | 停止本地模型 |
| `delete_private_model` | 删除本地模型 |
| `search_models` | 搜索模型 |
| `get_private_model_status_list` | 批量查询本地模型运行状态 |

### 组织管理（7）

| Tool | 说明 |
|------|------|
| `create_organization` | 创建组织 |
| `update_organization` | 更新组织 |
| `delete_organization` | 删除组织 |
| `get_organization` | 获取组织 |
| `get_organization_page` | 获取组织分页列表 |
| `get_organization_by_dept_id` | 根据部门ID获取组织 |
| `get_organization_member_page` | 获取组织成员分页列表 |

### 用户管理（7）

| Tool | 说明 |
|------|------|
| `create_user` | 创建用户 |
| `update_user` | 更新用户 |
| `delete_user` | 删除用户 |
| `get_user` | 获取用户 |
| `get_user_page` | 获取用户分页列表 |
| `reset_user_api_key` | 重置用户API Key |
| `update_user_quota` | 更新用户配额 |
| `reset_all_user_quota` | 重置所有用户的配额使用情况 |

### AI 应用（8）

| Tool | 说明 |
|------|------|
| `create_ai_app` | 创建AI应用 |
| `update_ai_app` | 更新AI应用 |
| `delete_ai_app` | 删除AI应用 |
| `get_ai_app` | 获取AI应用 |
| `get_ai_app_page` | 获取AI应用分页（普通用户） |
| `get_ai_app_manage_page` | 获取AI应用管理分页（管理员） |
| `publish_ai_app` | 发布AI应用 |
| `unpublish_ai_app` | 下架AI应用 |

### 应用管理（7）

| Tool | 说明 |
|------|------|
| `create_app` | 创建应用 |
| `update_app` | 更新应用 |
| `delete_app` | 删除应用 |
| `get_app` | 获取应用 |
| `get_app_page` | 获取应用分页 |
| `get_app_list` | 获取应用列表 |
| `publish_app` | 发布应用 |
| `unpublish_app` | 取消发布应用 |

### 应用部署（10）

| Tool | 说明 |
|------|------|
| `get_routing_list` | 获取路由策略列表 |
| `get_schedule_strategy_options` | 获取调度策略选项列表 |
| `deploy_instance` | 部署应用实例 |
| `get_deploy_progress` | 获取部署进度 |
| `get_instance_page` | 获取应用实例分页列表 |
| `get_instance` | 获取应用实例详情 |
| `start_instance` | 启动应用实例 |
| `stop_instance` | 停止应用实例 |
| `restart_instance` | 重启应用实例 |
| `delete_instance` | 删除应用实例 |
| `get_instance_token` | 获取应用实例访问Token |
| `get_instance_logs` | 获取应用实例日志 |
| `get_instance_status_list` | 批量查询应用实例状态 |

### 节点管理（9）

| Tool | 说明 |
|------|------|
| `create_node` | 创建节点 |
| `update_node` | 更新节点 |
| `delete_node` | 删除节点 |
| `get_node` | 获取节点 |
| `get_node_page` | 获取节点分页 |
| `get_node_list` | 获取节点列表 |
| `restart_node` | 重启节点 |
| `shutdown_node` | 关机节点 |
| `get_node_usage` | 批量查询节点使用率 |

### Agent 管理（2）

| Tool | 说明 |
|------|------|
| `register_agent` | Agent注册 |
| `get_network_interfaces` | 查询宿主机网卡IP列表 |

### 调用观测（4）

| Tool | 说明 |
|------|------|
| `get_observation_list` | 查询调用记录列表 |
| `get_observation_detail` | 查询调用链详情 |
| `get_observation_models` | 获取模型列表 |
| `get_platform_models` | 获取平台模型列表 |

### 用量概览（8）

| Tool | 说明 |
|------|------|
| `get_stats_cards` | 获取统计卡片 |
| `get_token_trend` | 获取Token消耗趋势 |
| `get_cost_trend` | 获取费用消耗趋势 |
| `get_model_distribution` | 获取模型使用分布 |
| `get_org_distribution` | 获取费用使用分布 |
| `get_org_quota_top5` | 获取组织配额使用TOP5 |
| `get_user_quota_top5` | 获取用户配额使用TOP5 |
| `get_detail_table` | 获取明细数据表 |

### Token 统计（7）

| Tool | 说明 |
|------|------|
| `get_token_stats_cards` | 获取Token统计卡片 |
| `get_token_stats_trend` | 获取Token消耗趋势 |
| `get_token_model_distribution` | 获取模型Token分布 |
| `get_token_model_top5` | 获取模型Token消耗TOP5 |
| `get_token_org_top5` | 获取组织Token消耗TOP5 |
| `get_token_user_top5` | 获取用户Token消耗TOP5 |
| `get_token_detail_table` | 获取明细数据表 |

### 统计管理（2）

| Tool | 说明 |
|------|------|
| `trigger_period_stats` | 手动触发周期统计 |
| `trigger_cleanup` | 手动触发数据清理 |

### MCP 服务（2）

| Tool | 说明 |
|------|------|
| `get_mcp_server_list` | 获取MCP服务列表 |
| `get_mcp_server_detail` | 获取MCP服务详情 |

## 项目结构

```
tao-mcp-server/
├── src/
│   ├── index.ts       # 入口：双模式启动、session 管理、认证提取
│   ├── tools.ts       # 109 个 MCP Tool 定义（Zod schema）
│   ├── handlers.ts    # API 请求路由、参数拼接、HTTP 调用
│   └── context.ts     # AsyncLocalStorage 认证上下文透传
├── start.sh           # 生产部署脚本
├── ecosystem.config.cjs # PM2 配置
├── package.json
├── tsconfig.json
├── .env.example
└── README.md
```

## 常见问题

### Tool 列表为空 / 健康检查正常但调用失败

1. 确认 MCP Client 透传了正确的认证信息（Cookie 或 Bearer Token）
2. 查看服务端日志：`cat logs/server.log`，搜索 `[MCP-AUTH]` 确认是否收到认证信息
3. 先直连后端 API 验证凭据有效：
   ```bash
   curl -H "Cookie: <your-cookie>" http://192.168.36.118:8888/admin-api/manage/routing/page
   ```

### 部署后进程消失

使用 `start.sh` 避免此问题——它使用 `node --import` 直接启动而非 `npx` 链式调用。

### 端口冲突

修改 `.env` 中的 `MCP_PORT`，或启动时指定：
```bash
./start.sh http 4567
```

### esbuild 跨平台错误

`start.sh` 会在目标平台自动执行 `npm install --production` 重新编译原生依赖。

## 技术栈

- **Runtime**: Node.js >= 18 + TypeScript (tsx)
- **MCP SDK**: @modelcontextprotocol/sdk ^1.27
- **Web Framework**: Express ^4.21
- **Schema Validation**: Zod ^4.3
- **Transport**: stdio / streamable-http (SSE)
- **Auth**: AsyncLocalStorage（请求级认证上下文）
