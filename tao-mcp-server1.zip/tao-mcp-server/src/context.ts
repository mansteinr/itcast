import { AsyncLocalStorage } from "node:async_hooks";

/** 请求级认证上下文 */
interface AuthContext {
  token: string;
  cookie: string;
}

/** 请求级 Auth 上下文 — 每个 HTTP 请求独立隔离 */
const storage = new AsyncLocalStorage<AuthContext>();

/**
 * 在认证上下文中执行回调。
 * 下游 apiRequest 通过 getRequestAuth() 自动获取，无需层层透传。
 */
export function runWithAuth(auth: AuthContext, fn: () => Promise<void>): Promise<void> {
  return storage.run(auth, fn);
}

/** 获取当前请求上下文中客户端透传的 Bearer token */
export function getRequestToken(): string {
  return storage.getStore()?.token ?? "";
}

/** 获取当前请求上下文中客户端透传的 Session Cookie */
export function getRequestCookie(): string {
  return storage.getStore()?.cookie ?? "";
}
