import { randomUUID } from "node:crypto";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { registerTools } from "./tools";
import { runWithAuth } from "./context";
import express from "express";

const PORT = parseInt(process.env.MCP_PORT ?? "9988", 10);
const USE_HTTP = process.env.MCP_TRANSPORT === "streamable-http";

// 工具注册工厂函数 — 每个 session 创建独立的 McpServer + transport
// Token 通过 AsyncLocalStorage 自动注入，无需 getToken 参数
function createServer(): McpServer {
  const server = new McpServer({
    name: "TrendyAgentOps 管理后台 API",
    version: "0.1.0",
  });
  registerTools(server);
  return server;
}

async function startStdio() {
  const server = createServer();
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("TrendyAgentOps MCP Server running (stdio, 109 tools)");
}

async function startStreamableHttp() {
  const app = express();
  app.use(express.json());

  // sessionId → transport 缓存
  const sessions = new Map<string, StreamableHTTPServerTransport>();

  // 首次请求创建的 transport（sessionId 还未确定时使用）
  let pendingTransport: StreamableHTTPServerTransport | null = null;

  app.get("/health", (_req, res) => {
    res.json({ status: "ok", tools: 109 });
  });

  app.all("/mcp", async (req, res) => {
    const sessionId = req.headers["mcp-session-id"] as string | undefined;

    // 从请求头提取认证信息（支持 Authorization: Bearer xxx 和 Session Cookie）
    const clientToken =
      (req.headers["authorization"] as string)?.replace(/^Bearer\s+/i, "") ||
      (req.headers["x-api-key"] as string) ||
      "";
    const clientCookie = (req.headers["x-session-cookie"] as string) || (req.headers["cookie"] as string) || "";
    console.error(`[MCP-AUTH] clientToken=${clientToken ? clientToken.substring(0, 10) + "..." : "(empty)"}, cookie=${clientCookie ? clientCookie.substring(0, 20) + "..." : "(empty)"}`);

    // 将认证信息注入当前请求的异步上下文，下游 apiRequest 自动获取
    await runWithAuth({ token: clientToken, cookie: clientCookie }, async () => {
      // 复用已有 session
      const session = sessionId ? sessions.get(sessionId) : undefined;

      if (session) {
        await session.handleRequest(req, res, req.body);
      } else {
        // 新 session：创建 transport + server
        const transport = new StreamableHTTPServerTransport({
          sessionIdGenerator: () => randomUUID(),
          onsessioninitialized: (id) => {
            console.error(`[MCP] Session initialized: ${id}`);
          },
        });

        const server = createServer();
        await server.connect(transport);

        transport.onclose = () => {
          const id = transport.sessionId;
          if (id) {
            console.error(`[MCP] Session closed: ${id}`);
            sessions.delete(id);
          }
        };

        // 拦截响应 finish 事件，从响应头中获取 mcp-session-id 并缓存
        res.on("finish", () => {
          const newSessionId = res.getHeader("mcp-session-id") as string | undefined;
          if (newSessionId) {
            sessions.set(newSessionId, transport);
          }
          if (pendingTransport === transport) {
            pendingTransport = null;
          }
        });

        pendingTransport = transport;
        await transport.handleRequest(req, res, req.body);
      }
    });
  });

  app.listen(PORT, () => {
    console.error(`TrendyAgentOps MCP Server running (streamable-http :${PORT}, 109 tools)`);
  });
}

async function main() {
  if (USE_HTTP) {
    await startStreamableHttp();
  } else {
    await startStdio();
  }
}

main().catch((error) => {
  console.error("Fatal error:", error);
  process.exit(1);
});
