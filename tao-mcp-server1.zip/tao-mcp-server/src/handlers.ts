import { getRequestToken, getRequestCookie } from "./context";

const BASE_URL = process.env.API_BASE_URL ?? "http://192.168.36.118:8888/";

interface ToolResult {
  [key: string]: unknown;
  content: Array<{ type: "text"; text: string }>;
  isError?: boolean;
}

export async function handleToolCall(
  toolName: string,
  params: Record<string, unknown>,
): Promise<ToolResult> {
  const startTime = Date.now();
  console.error(`[MCP] >>> ${toolName} called at ${new Date().toISOString()}`);
  console.error(`[MCP] >>> params:`, JSON.stringify(params));

  try {
    const handler = HANDLERS[toolName];
    if (!handler) {
      const result = errorResult(`Unknown tool: ${toolName}`);
      console.error(`[MCP] <<< ${toolName} ERROR (unknown tool)`);
      return result;
    }
    const result = await handler(params);
    const elapsed = Date.now() - startTime;
    const status = result.isError ? "ERROR" : "OK";
    console.error(`[MCP] <<< ${toolName} ${status} (${elapsed}ms)`);
    return result;
  } catch (err) {
    const elapsed = Date.now() - startTime;
    const message = err instanceof Error ? err.message : String(err);
    console.error(`[MCP] <<< ${toolName} FAIL (${elapsed}ms): ${message}`);
    return errorResult(`Tool ${toolName} failed: ${message}`);
  }
}

function errorResult(message: string): ToolResult {
  return {
    content: [{ type: "text", text: message }],
    isError: true,
  };
}

function successResult(data: unknown): ToolResult {
  return {
    content: [{
      type: "text",
      text: typeof data === "string" ? data : JSON.stringify(data, null, 2),
    }],
  };
}

async function apiRequest(
  method: string,
  path: string,
  params?: Record<string, unknown>,
  queryParamNames?: ReadonlyArray<string>,
): Promise<unknown> {
  let url = BASE_URL.replace(/\/+$/, "") + "/" + path.replace(/^\/+/, "");

  const usedKeys = new Set<string>();

  // Replace path parameters
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      const placeholder = `{${key}}`;
      if (url.includes(placeholder)) {
        url = url.replace(placeholder, encodeURIComponent(String(value)));
        usedKeys.add(key);
      }
    }
  }

  // Build query string from params that are explicitly query params
  // For GET/DELETE/HEAD: all non-path params are query params
  // For POST/PUT/PATCH: only params listed in queryParamNames are query params
  const queryKeys = new Set<string>();
  if (params) {
    const isBodyMethod = method !== "GET" && method !== "DELETE" && method !== "HEAD";
    const queryEntries: string[] = [];
    for (const [key, value] of Object.entries(params)) {
      if (usedKeys.has(key) || value === undefined) continue;
      const isQuery = isBodyMethod
        ? (queryParamNames ?? []).includes(key)
        : true;
      if (isQuery) {
        queryEntries.push(`${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);
        queryKeys.add(key);
      }
    }
    if (queryEntries.length > 0) {
      url += "?" + queryEntries.join("&");
    }
  }

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    "Accept": "application/json",
  };

  // 从当前请求上下文获取客户端透传的认证信息
  const token = getRequestToken();
  const cookie = getRequestCookie();
  console.error(`[MCP-AUTH] apiRequest token=${token ? token.substring(0, 10) + "..." : "(empty)"}, cookie=${cookie ? cookie.substring(0, 20) + "..." : "(empty)"}, path=${path}`);
  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }
  // Session Cookie 透传 — 这是后端实际使用的鉴权方式
  if (cookie) {
    headers["Cookie"] = cookie;
  }
  const fetchOptions: RequestInit = {
    method: method.toUpperCase(),
    headers,
  };

  if (method !== "GET" && method !== "DELETE" && method !== "HEAD" && params) {
    // Body = all params that are NOT path params and NOT query params
    const bodyParams: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(params)) {
      if (!usedKeys.has(key) && !queryKeys.has(key)) {
        bodyParams[key] = value;
      }
    }
    if (Object.keys(bodyParams).length > 0) {
      fetchOptions.body = JSON.stringify(bodyParams);
    }
  }

  console.error(`[MCP]   HTTP ${method} ${url}`);
  if (fetchOptions.body) {
    console.error(`[MCP]   body:`, fetchOptions.body);
  }

  const fetchStart = Date.now();
  const response = await fetch(url, fetchOptions);
  const fetchTime = Date.now() - fetchStart;

  console.error(`[MCP]   response ${response.status} (${fetchTime}ms)`);

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`[MCP]   error body:`, errorText.substring(0, 500));
    throw new Error(`API error ${response.status}: ${errorText}`);
  }

  const contentType = response.headers.get("content-type") ?? "";
  if (contentType.includes("application/json")) {
    const json = await response.json();
    console.error(`[MCP]   response JSON length:`, JSON.stringify(json).length);
    return json;
  }
  const text = await response.text();
  console.error(`[MCP]   response TEXT length:`, text.length);
  return text;
}

const HANDLERS: Record<string, (params: Record<string, unknown>) => Promise<ToolResult>> = {
  "create_routing_strategy": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/routing/create", params, []);
    return successResult(result);
  },
  "update_routing_strategy": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/routing/update", params, []);
    return successResult(result);
  },
  "delete_routing_strategy": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/routing/delete", params, ["id","routingType"]);
    return successResult(result);
  },
  "get_routing_strategy": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/routing/get", params, ["id","routingType"]);
    return successResult(result);
  },
  "get_routing_strategy_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/routing/page", params, ["routingType","name","status","pageNo","pageSize"]);
    return successResult(result);
  },
  "enable_routing_strategy": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/routing/enable", params, []);
    return successResult(result);
  },
  "get_base_url_config": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/routing/base-url", params, []);
    return successResult(result);
  },
  "update_base_url_config": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/routing/base-url", params, []);
    return successResult(result);
  },
  "get_plugin_list": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/routing/{id}/plugins", params, []);
    return successResult(result);
  },
  "toggle_plugin": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/routing/{id}/plugins/{pluginName}/toggle", params, []);
    return successResult(result);
  },
  "get_plugin_config": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/routing/{id}/plugins/{pluginName}/config", params, []);
    return successResult(result);
  },
  "save_plugin_config": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/routing/{id}/plugins/{pluginName}/config", params, []);
    return successResult(result);
  },
  "create_provider": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/llm-provider/create", params, []);
    return successResult(result);
  },
  "update_provider": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/llm-provider/update", params, []);
    return successResult(result);
  },
  "delete_provider": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/llm-provider/delete", params, ["id"]);
    return successResult(result);
  },
  "get_provider": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/llm-provider/get", params, ["id"]);
    return successResult(result);
  },
  "get_provider_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/llm-provider/page", params, ["pageNo","pageSize"]);
    return successResult(result);
  },
  "get_provider_models": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/llm-provider/models", params, ["id"]);
    return successResult(result);
  },
  "init_smart_router_provider_routes": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/llm-provider/init-smart-router-routes", params, []);
    return successResult(result);
  },
  "get_llm_model": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/llm-model/get", params, ["id"]);
    return successResult(result);
  },
  "get_llm_model_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/llm-model/page", params, ["pageNo","pageSize"]);
    return successResult(result);
  },
  "update_rate": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/llm-model/rate", params, []);
    return successResult(result);
  },
  "create_public_model": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/llm-model/create-public", params, []);
    return successResult(result);
  },
  "delete_public_model": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/llm-model/delete-public", params, ["id"]);
    return successResult(result);
  },
  "create_private_model": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/llm-model/create-private", params, []);
    return successResult(result);
  },
  "get_model_add_progress": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/llm-model/add-progress", params, ["taskId"]);
    return successResult(result);
  },
  "start_private_model": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/llm-model/start-private", params, ["id"]);
    return successResult(result);
  },
  "stop_private_model": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/llm-model/stop-private", params, ["id"]);
    return successResult(result);
  },
  "delete_private_model": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/llm-model/delete-private", params, ["id"]);
    return successResult(result);
  },
  "search_models": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/llm-model/search", params, ["keyword","limit"]);
    return successResult(result);
  },
  "get_private_model_status_list": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/llm-model/private-status", params, ["ids"]);
    return successResult(result);
  },
  "create_organization": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/organization/create", params, []);
    return successResult(result);
  },
  "update_organization": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/organization/update", params, []);
    return successResult(result);
  },
  "delete_organization": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/organization/delete", params, ["id"]);
    return successResult(result);
  },
  "get_organization": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/organization/get", params, ["id"]);
    return successResult(result);
  },
  "get_organization_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/organization/page", params, ["pageNo","pageSize"]);
    return successResult(result);
  },
  "get_organization_by_dept_id": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/organization/get-by-dept-id", params, ["deptId"]);
    return successResult(result);
  },
  "get_organization_member_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/organization/members/page", params, ["orgId","pageNo","pageSize"]);
    return successResult(result);
  },
  "create_user": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/user/create", params, []);
    return successResult(result);
  },
  "update_user": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/user/update", params, []);
    return successResult(result);
  },
  "delete_user": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/user/delete", params, ["id"]);
    return successResult(result);
  },
  "get_user": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/user/get", params, ["id"]);
    return successResult(result);
  },
  "get_user_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/user/page", params, ["pageNo","pageSize"]);
    return successResult(result);
  },
  "reset_user_api_key": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/user/reset-api-key", params, ["id"]);
    return successResult(result);
  },
  "update_user_quota": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/user/update-quota", params, ["id","monthlyTokenQuota","monthlyCostQuota"]);
    return successResult(result);
  },
  "reset_all_user_quota": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/user/resetAllUserQuota", params, []);
    return successResult(result);
  },
  "create_ai_app": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/ai-app/create", params, []);
    return successResult(result);
  },
  "update_ai_app": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/ai-app/update", params, []);
    return successResult(result);
  },
  "delete_ai_app": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/ai-app/delete", params, ["id"]);
    return successResult(result);
  },
  "get_ai_app": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/ai-app/get", params, ["id"]);
    return successResult(result);
  },
  "get_ai_app_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/ai-app/page", params, ["name","status","pageNo","pageSize"]);
    return successResult(result);
  },
  "get_ai_app_manage_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/ai-app/manage/page", params, ["name","status","pageNo","pageSize"]);
    return successResult(result);
  },
  "publish_ai_app": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/ai-app/publish", params, ["id"]);
    return successResult(result);
  },
  "unpublish_ai_app": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/ai-app/unpublish", params, ["id"]);
    return successResult(result);
  },
  "create_app": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/app/create", params, []);
    return successResult(result);
  },
  "update_app": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/app/update", params, []);
    return successResult(result);
  },
  "delete_app": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/app/delete", params, ["id"]);
    return successResult(result);
  },
  "get_app": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app/get", params, ["id"]);
    return successResult(result);
  },
  "get_app_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app/page", params, ["pageNo","pageSize"]);
    return successResult(result);
  },
  "get_app_list": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app/list", params, ["name"]);
    return successResult(result);
  },
  "publish_app": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/app/publish", params, ["id"]);
    return successResult(result);
  },
  "unpublish_app": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/app/unpublish", params, ["id"]);
    return successResult(result);
  },
  "get_routing_list": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app/routings", params, []);
    return successResult(result);
  },
  "get_schedule_strategy_options": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app/schedule-strategy-options", params, []);
    return successResult(result);
  },
  "deploy_instance": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/app-instance/deploy", params, []);
    return successResult(result);
  },
  "get_deploy_progress": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app-instance/deploy-progress", params, ["taskId"]);
    return successResult(result);
  },
  "get_instance_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app-instance/page", params, ["pageNo","pageSize"]);
    return successResult(result);
  },
  "get_instance": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app-instance/get", params, ["id"]);
    return successResult(result);
  },
  "start_instance": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/app-instance/start", params, ["id"]);
    return successResult(result);
  },
  "stop_instance": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/app-instance/stop", params, ["id"]);
    return successResult(result);
  },
  "restart_instance": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/app-instance/restart", params, ["id"]);
    return successResult(result);
  },
  "delete_instance": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/app-instance/delete", params, ["id"]);
    return successResult(result);
  },
  "get_instance_token": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app-instance/token", params, ["id"]);
    return successResult(result);
  },
  "get_instance_logs": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app-instance/logs", params, ["id","tail"]);
    return successResult(result);
  },
  "get_instance_status_list": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/app-instance/status", params, ["ids"]);
    return successResult(result);
  },
  "create_node": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/node/create", params, []);
    return successResult(result);
  },
  "update_node": async (params) => {
    const result = await apiRequest("PUT", "/admin-api/manage/node/update", params, []);
    return successResult(result);
  },
  "delete_node": async (params) => {
    const result = await apiRequest("DELETE", "/admin-api/manage/node/delete", params, ["id"]);
    return successResult(result);
  },
  "get_node": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/node/get", params, ["id"]);
    return successResult(result);
  },
  "get_node_page": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/node/page", params, ["pageNo","pageSize"]);
    return successResult(result);
  },
  "get_node_list": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/node/list", params, []);
    return successResult(result);
  },
  "restart_node": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/node/restart", params, ["id"]);
    return successResult(result);
  },
  "shutdown_node": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/node/shutdown", params, ["id"]);
    return successResult(result);
  },
  "get_node_usage": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/node/usage", params, []);
    return successResult(result);
  },
  "register_agent": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/agent/register", params, []);
    return successResult(result);
  },
  "get_network_interfaces": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/agent/network/interfaces", params, []);
    return successResult(result);
  },
  "get_observation_list": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/observation/list", params, ["pageNo","pageSize","model","keyword","startTime","endTime","orderBy","orderDirection"]);
    return successResult(result);
  },
  "get_observation_detail": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/observation/detail", params, ["observationId","traceId"]);
    return successResult(result);
  },
  "get_observation_models": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/observation/models", params, []);
    return successResult(result);
  },
  "get_platform_models": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/observation/platform-models", params, []);
    return successResult(result);
  },
  "get_stats_cards": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/overview/stats-cards", params, ["dimension"]);
    return successResult(result);
  },
  "get_token_trend": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/overview/token-trend", params, ["dimension"]);
    return successResult(result);
  },
  "get_cost_trend": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/overview/cost-trend", params, ["dimension"]);
    return successResult(result);
  },
  "get_model_distribution": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/overview/model-distribution", params, ["dimension"]);
    return successResult(result);
  },
  "get_org_distribution": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/overview/org-distribution", params, ["dimension"]);
    return successResult(result);
  },
  "get_org_quota_top5": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/overview/org-quota-top5", params, ["dimension","quotaType"]);
    return successResult(result);
  },
  "get_user_quota_top5": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/overview/user-quota-top5", params, ["dimension","quotaType"]);
    return successResult(result);
  },
  "get_detail_table": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/overview/detail-table", params, ["pageNo","pageSize"]);
    return successResult(result);
  },
  "get_token_stats_cards": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/token-stats/cards", params, ["dimension"]);
    return successResult(result);
  },
  "get_token_stats_trend": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/token-stats/trend", params, ["dimension"]);
    return successResult(result);
  },
  "get_token_model_distribution": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/token-stats/model-distribution", params, ["dimension","type"]);
    return successResult(result);
  },
  "get_token_model_top5": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/token-stats/model-top5", params, ["dimension","type"]);
    return successResult(result);
  },
  "get_token_org_top5": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/token-stats/org-top5", params, ["dimension","type"]);
    return successResult(result);
  },
  "get_token_user_top5": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/token-stats/user-top5", params, ["dimension","type"]);
    return successResult(result);
  },
  "get_token_detail_table": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/token-stats/detail-table", params, ["pageNo","pageSize"]);
    return successResult(result);
  },
  "trigger_period_stats": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/stats/period-stats", params, ["periodMinutes"]);
    return successResult(result);
  },
  "trigger_cleanup": async (params) => {
    const result = await apiRequest("POST", "/admin-api/manage/stats/cleanup", params, []);
    return successResult(result);
  },
  "get_mcp_server_list": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/mcp/list", params, ["ts","pageNum","pageSize"]);
    return successResult(result);
  },
  "get_mcp_server_detail": async (params) => {
    const result = await apiRequest("GET", "/admin-api/manage/mcp/detail/{serverName}", params, ["ts"]);
    return successResult(result);
  },
};
