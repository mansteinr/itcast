import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { handleToolCall } from "./handlers";

export function registerTools(server: McpServer): void {
  server.tool(
    "create_routing_strategy",
    "创建路由规则",
    {
    "id": z.number().describe("路由ID（更新时必填）").optional(),
    "routingType": z.number().describe("路由类型：1-手动路由，2-智能路由"),
    "name": z.string().describe("路由名称"),
    "externalModelName": z.string().describe("对外模型名"),
    "targetModels": z.array(z.any()).describe("目标模型配置列表"),
    "fallbackConfig": z.record(z.string(), z.any()).describe("降级配置").optional(),
    "authConfig": z.record(z.string(), z.any()).describe("认证配置").optional(),
    "defaultProviderId": z.number().describe("默认供应商ID（智能路由专用）").optional(),
    "defaultModelId": z.number().describe("默认模型ID（智能路由专用）").optional(),
    "defaultProviderName": z.string().describe("默认供应商名称（智能路由专用）").optional(),
    "defaultModelName": z.string().describe("默认模型名称（智能路由专用）").optional(),
  },
    async (params) => handleToolCall("create_routing_strategy", params),
  );

  server.tool(
    "update_routing_strategy",
    "更新路由规则",
    {
    "id": z.number().describe("路由ID（更新时必填）").optional(),
    "routingType": z.number().describe("路由类型：1-手动路由，2-智能路由"),
    "name": z.string().describe("路由名称"),
    "externalModelName": z.string().describe("对外模型名"),
    "targetModels": z.array(z.any()).describe("目标模型配置列表"),
    "fallbackConfig": z.record(z.string(), z.any()).describe("降级配置").optional(),
    "authConfig": z.record(z.string(), z.any()).describe("认证配置").optional(),
    "defaultProviderId": z.number().describe("默认供应商ID（智能路由专用）").optional(),
    "defaultModelId": z.number().describe("默认模型ID（智能路由专用）").optional(),
    "defaultProviderName": z.string().describe("默认供应商名称（智能路由专用）").optional(),
    "defaultModelName": z.string().describe("默认模型名称（智能路由专用）").optional(),
  },
    async (params) => handleToolCall("update_routing_strategy", params),
  );

  server.tool(
    "delete_routing_strategy",
    "删除路由规则",
    {
    "id": z.number().describe("路由规则ID"),
    "routingType": z.number().describe("路由类型：1-手动路由，2-智能路由"),
  },
    async (params) => handleToolCall("delete_routing_strategy", params),
  );

  server.tool(
    "get_routing_strategy",
    "获取路由规则详情",
    {
    "id": z.number().describe("路由规则ID"),
    "routingType": z.number().describe("路由类型：1-手动路由，2-智能路由"),
  },
    async (params) => handleToolCall("get_routing_strategy", params),
  );

  server.tool(
    "get_routing_strategy_page",
    "获取路由规则分页列表",
    {
    "routingType": z.number().describe("路由类型：1-手动路由，2-智能路由").optional(),
    "name": z.string().describe("路由名称，模糊匹配").optional(),
    "status": z.number().describe("状态：0-禁用，1-启用").optional(),
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_routing_strategy_page", params),
  );

  server.tool(
    "enable_routing_strategy",
    "启用/禁用路由规则",
    {
    "id": z.number().describe("路由ID"),
    "status": z.number().describe("状态：0-禁用，1-启用"),
    "routingType": z.number().describe("路由类型：1-手动路由，2-智能路由"),
  },
    async (params) => handleToolCall("enable_routing_strategy", params),
  );

  server.tool(
    "get_base_url_config",
    "获取 BaseURL 配置",
    {},
    async (params) => handleToolCall("get_base_url_config", params),
  );

  server.tool(
    "update_base_url_config",
    "设置 BaseURL 配置",
    {
    "ip": z.string().describe("IP地址").optional(),
    "customPath": z.string().describe("自定义路径").optional(),
    "ignoreCase": z.boolean().describe("是否忽略大小写"),
  },
    async (params) => handleToolCall("update_base_url_config", params),
  );

  server.tool(
    "get_plugin_list",
    "获取路由的所有插件列表",
    {
    "id": z.number().describe("路由策略ID"),
  },
    async (params) => handleToolCall("get_plugin_list", params),
  );

  server.tool(
    "toggle_plugin",
    "启用/停用插件",
    {
    "id": z.number().describe("路由策略ID"),
    "pluginName": z.string().describe("插件名称"),
    "enabled": z.boolean().describe("是否启用"),
  },
    async (params) => handleToolCall("toggle_plugin", params),
  );

  server.tool(
    "get_plugin_config",
    "获取插件配置详情",
    {
    "id": z.number().describe("路由策略ID"),
    "pluginName": z.string().describe("插件名称"),
  },
    async (params) => handleToolCall("get_plugin_config", params),
  );

  server.tool(
    "save_plugin_config",
    "保存插件配置",
    {
    "id": z.number().describe("路由策略ID"),
    "pluginName": z.string().describe("插件名称"),
    "body": z.record(z.string(), z.any()).describe("路由插件配置保存请求"),
  },
    async (params) => handleToolCall("save_plugin_config", params),
  );

  server.tool(
    "create_provider",
    "创建供应商",
    {
    "id": z.number().describe("供应商ID（修改时必填）").optional(),
    "name": z.string().describe("供应商名称"),
    "type": z.string().describe("供应商类型"),
    "protocol": z.string().describe("协议类型").optional(),
    "status": z.number().describe("状态：0-禁用，1-启用").optional(),
    "openaiServiceType": z.number().describe("OpenAI服务类型：1-官方，2-自定义").optional(),
    "baseUrls": z.array(z.any()).describe("BaseURL列表").optional(),
    "credentials": z.array(z.any()).describe("API Key列表").optional(),
    "syncConfig": z.record(z.string(), z.any()).describe("模型同步配置请求").optional(),
    "ollamaHost": z.string().describe("Ollama服务主机名").optional(),
    "ollamaPort": z.number().describe("Ollama服务端口").optional(),
    "azureServiceUrl": z.string().describe("Azure服务URL").optional(),
    "awsAccessKey": z.string().describe("AWS访问密钥").optional(),
    "awsSecretKey": z.string().describe("AWS秘密密钥").optional(),
    "awsRegion": z.string().describe("AWS区域").optional(),
    "vertexAuthKey": z.string().describe("Vertex认证密钥").optional(),
    "vertexRegion": z.string().describe("Vertex区域").optional(),
    "vertexProjectId": z.string().describe("Vertex项目ID").optional(),
    "qwenDomain": z.string().describe("Qwen自定义域名").optional(),
    "qwenEnableSearch": z.boolean().describe("Qwen启用搜索").optional(),
    "qwenEnableCompatible": z.boolean().describe("Qwen启用兼容模式").optional(),
    "qwenFileIds": z.array(z.any()).describe("Qwen文件ID列表").optional(),
    "claudeVersion": z.string().describe("Claude版本").optional(),
    "claudeCodeMode": z.boolean().describe("Claude代码模式").optional(),
    "zhipuDomain": z.string().describe("智谱AI自定义域名").optional(),
    "zhipuCodePlanMode": z.boolean().describe("智谱AI代码计划模式").optional(),
    "openaiCustomUrl": z.string().describe("OpenAI自定义URL").optional(),
    "openaiExtraCustomUrls": z.array(z.any()).describe("OpenAI额外自定义URL列表").optional(),
    "openaiCustomServiceName": z.string().describe("OpenAI自定义服务名称").optional(),
    "openaiCustomServicePort": z.number().describe("OpenAI自定义服务端口").optional(),
    "rawConfigs": z.record(z.string(), z.any()).describe("原始配置").optional(),
    "tokenFailoverConfig": z.record(z.string(), z.any()).describe("Token故障转移配置").optional(),
  },
    async (params) => handleToolCall("create_provider", params),
  );

  server.tool(
    "update_provider",
    "更新供应商",
    {
    "id": z.number().describe("供应商ID（修改时必填）").optional(),
    "name": z.string().describe("供应商名称"),
    "type": z.string().describe("供应商类型"),
    "protocol": z.string().describe("协议类型").optional(),
    "status": z.number().describe("状态：0-禁用，1-启用").optional(),
    "openaiServiceType": z.number().describe("OpenAI服务类型：1-官方，2-自定义").optional(),
    "baseUrls": z.array(z.any()).describe("BaseURL列表").optional(),
    "credentials": z.array(z.any()).describe("API Key列表").optional(),
    "syncConfig": z.record(z.string(), z.any()).describe("模型同步配置请求").optional(),
    "ollamaHost": z.string().describe("Ollama服务主机名").optional(),
    "ollamaPort": z.number().describe("Ollama服务端口").optional(),
    "azureServiceUrl": z.string().describe("Azure服务URL").optional(),
    "awsAccessKey": z.string().describe("AWS访问密钥").optional(),
    "awsSecretKey": z.string().describe("AWS秘密密钥").optional(),
    "awsRegion": z.string().describe("AWS区域").optional(),
    "vertexAuthKey": z.string().describe("Vertex认证密钥").optional(),
    "vertexRegion": z.string().describe("Vertex区域").optional(),
    "vertexProjectId": z.string().describe("Vertex项目ID").optional(),
    "qwenDomain": z.string().describe("Qwen自定义域名").optional(),
    "qwenEnableSearch": z.boolean().describe("Qwen启用搜索").optional(),
    "qwenEnableCompatible": z.boolean().describe("Qwen启用兼容模式").optional(),
    "qwenFileIds": z.array(z.any()).describe("Qwen文件ID列表").optional(),
    "claudeVersion": z.string().describe("Claude版本").optional(),
    "claudeCodeMode": z.boolean().describe("Claude代码模式").optional(),
    "zhipuDomain": z.string().describe("智谱AI自定义域名").optional(),
    "zhipuCodePlanMode": z.boolean().describe("智谱AI代码计划模式").optional(),
    "openaiCustomUrl": z.string().describe("OpenAI自定义URL").optional(),
    "openaiExtraCustomUrls": z.array(z.any()).describe("OpenAI额外自定义URL列表").optional(),
    "openaiCustomServiceName": z.string().describe("OpenAI自定义服务名称").optional(),
    "openaiCustomServicePort": z.number().describe("OpenAI自定义服务端口").optional(),
    "rawConfigs": z.record(z.string(), z.any()).describe("原始配置").optional(),
    "tokenFailoverConfig": z.record(z.string(), z.any()).describe("Token故障转移配置").optional(),
  },
    async (params) => handleToolCall("update_provider", params),
  );

  server.tool(
    "delete_provider",
    "删除供应商",
    {
    "id": z.number().describe("供应商ID"),
  },
    async (params) => handleToolCall("delete_provider", params),
  );

  server.tool(
    "get_provider",
    "获取供应商",
    {
    "id": z.number().describe("供应商ID"),
  },
    async (params) => handleToolCall("get_provider", params),
  );

  server.tool(
    "get_provider_page",
    "获取供应商分页列表",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_provider_page", params),
  );

  server.tool(
    "get_provider_models",
    "获取供应商关联的模型信息",
    {
    "id": z.number().describe("供应商ID"),
  },
    async (params) => handleToolCall("get_provider_models", params),
  );

  server.tool(
    "init_smart_router_provider_routes",
    "初始化所有供应商的智能路由分发层路由",
    {},
    async (params) => handleToolCall("init_smart_router_provider_routes", params),
  );

  server.tool(
    "get_llm_model",
    "获取模型详情",
    {
    "id": z.number().describe("模型ID"),
  },
    async (params) => handleToolCall("get_llm_model", params),
  );

  server.tool(
    "get_llm_model_page",
    "获取模型分页列表",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_llm_model_page", params),
  );

  server.tool(
    "update_rate",
    "设置模型费率",
    {
    "id": z.number().describe("模型ID"),
    "inputRate": z.number().describe("输入费率（¥/1M Tokens）").optional(),
    "outputRate": z.number().describe("输出费率（¥/1M Tokens）").optional(),
  },
    async (params) => handleToolCall("update_rate", params),
  );

  server.tool(
    "create_public_model",
    "添加公共模型",
    {
    "body": z.record(z.string(), z.any()).describe("公共模型创建请求"),
  },
    async (params) => handleToolCall("create_public_model", params),
  );

  server.tool(
    "delete_public_model",
    "删除公共模型",
    {
    "id": z.number().describe("模型ID"),
  },
    async (params) => handleToolCall("delete_public_model", params),
  );

  server.tool(
    "create_private_model",
    "添加本地模型",
    {
    "body": z.record(z.string(), z.any()).describe("本地模型创建请求"),
  },
    async (params) => handleToolCall("create_private_model", params),
  );

  server.tool(
    "get_model_add_progress",
    "获取本地模型添加进度",
    {
    "taskId": z.string().describe("添加任务ID"),
  },
    async (params) => handleToolCall("get_model_add_progress", params),
  );

  server.tool(
    "start_private_model",
    "启动本地模型",
    {
    "id": z.number().describe("模型ID"),
  },
    async (params) => handleToolCall("start_private_model", params),
  );

  server.tool(
    "stop_private_model",
    "停止本地模型",
    {
    "id": z.number().describe("模型ID"),
  },
    async (params) => handleToolCall("stop_private_model", params),
  );

  server.tool(
    "delete_private_model",
    "删除本地模型",
    {
    "id": z.number().describe("模型ID"),
  },
    async (params) => handleToolCall("delete_private_model", params),
  );

  server.tool(
    "search_models",
    "搜索模型",
    {
    "keyword": z.string().describe("搜索关键字"),
    "limit": z.number().describe("返回结果数量限制").optional(),
  },
    async (params) => handleToolCall("search_models", params),
  );

  server.tool(
    "get_private_model_status_list",
    "批量查询本地模型运行状态",
    {
    "ids": z.array(z.any()).describe("模型ID集合"),
  },
    async (params) => handleToolCall("get_private_model_status_list", params),
  );

  server.tool(
    "create_organization",
    "创建组织",
    {
    "id": z.number().describe("组织ID（修改时必填）").optional(),
    "name": z.string().describe("组织名称"),
    "parentId": z.number().describe("上级组织ID").optional(),
    "description": z.string().describe("组织描述").optional(),
    "enableDefaultQuota": z.boolean().describe("是否启用默认成员配额").optional(),
    "defaultTotalTokenQuota": z.number().describe("默认成员总Token配额/月").optional(),
    "defaultCostQuota": z.number().describe("默认成员费用配额/月").optional(),
    "defaultInstanceQuota": z.number().describe("默认成员实例配额").optional(),
  },
    async (params) => handleToolCall("create_organization", params),
  );

  server.tool(
    "update_organization",
    "更新组织",
    {
    "id": z.number().describe("组织ID（修改时必填）").optional(),
    "name": z.string().describe("组织名称"),
    "parentId": z.number().describe("上级组织ID").optional(),
    "description": z.string().describe("组织描述").optional(),
    "enableDefaultQuota": z.boolean().describe("是否启用默认成员配额").optional(),
    "defaultTotalTokenQuota": z.number().describe("默认成员总Token配额/月").optional(),
    "defaultCostQuota": z.number().describe("默认成员费用配额/月").optional(),
    "defaultInstanceQuota": z.number().describe("默认成员实例配额").optional(),
  },
    async (params) => handleToolCall("update_organization", params),
  );

  server.tool(
    "delete_organization",
    "删除组织",
    {
    "id": z.number().describe("组织ID"),
  },
    async (params) => handleToolCall("delete_organization", params),
  );

  server.tool(
    "get_organization",
    "获取组织",
    {
    "id": z.number().describe("组织ID"),
  },
    async (params) => handleToolCall("get_organization", params),
  );

  server.tool(
    "get_organization_page",
    "获取组织分页列表",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_organization_page", params),
  );

  server.tool(
    "get_organization_by_dept_id",
    "根据部门ID获取组织",
    {
    "deptId": z.number().describe("部门ID"),
  },
    async (params) => handleToolCall("get_organization_by_dept_id", params),
  );

  server.tool(
    "get_organization_member_page",
    "获取组织成员分页列表",
    {
    "orgId": z.number().describe("组织ID"),
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_organization_member_page", params),
  );

  server.tool(
    "create_user",
    "创建用户",
    {
    "username": z.string().describe("用户名"),
    "nickname": z.string().describe("用户昵称"),
    "password": z.string().describe("密码"),
    "mobile": z.string().describe("手机号").optional(),
    "email": z.string().describe("邮箱").optional(),
    "deptId": z.number().describe("部门编号"),
    "monthlyTokenQuota": z.number().describe("月度Token配额(0:不限)").optional(),
    "monthlyCostQuota": z.number().describe("月度费用配额（元，0:不限）").optional(),
    "instanceQuota": z.number().describe("实例配额").optional(),
    "roleId": z.number().describe("角色ID"),
  },
    async (params) => handleToolCall("create_user", params),
  );

  server.tool(
    "update_user",
    "更新用户",
    {
    "id": z.number().describe("用户扩展信息ID"),
    "nickname": z.string().describe("用户昵称"),
    "mobile": z.string().describe("手机号").optional(),
    "email": z.string().describe("邮箱").optional(),
    "deptId": z.number().describe("部门编号"),
    "monthlyTokenQuota": z.number().optional(),
    "monthlyCostQuota": z.number().optional(),
    "instanceQuota": z.number().optional(),
    "roleId": z.number(),
  },
    async (params) => handleToolCall("update_user", params),
  );

  server.tool(
    "delete_user",
    "删除用户",
    {
    "id": z.number().describe("用户ID"),
  },
    async (params) => handleToolCall("delete_user", params),
  );

  server.tool(
    "get_user",
    "获取用户",
    {
    "id": z.number().describe("用户ID"),
  },
    async (params) => handleToolCall("get_user", params),
  );

  server.tool(
    "get_user_page",
    "获取用户分页列表",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_user_page", params),
  );

  server.tool(
    "reset_user_api_key",
    "重置用户API Key",
    {
    "id": z.number().describe("用户ID"),
  },
    async (params) => handleToolCall("reset_user_api_key", params),
  );

  server.tool(
    "update_user_quota",
    "更新用户配额",
    {
    "id": z.number().describe("用户ID"),
    "monthlyTokenQuota": z.number().describe("月度Token配额"),
    "monthlyCostQuota": z.number().describe("月度费用配额"),
  },
    async (params) => handleToolCall("update_user_quota", params),
  );

  server.tool(
    "reset_all_user_quota",
    "重置所有用户的配额使用情况",
    {},
    async (params) => handleToolCall("reset_all_user_quota", params),
  );

  server.tool(
    "create_ai_app",
    "创建AI应用",
    {
    "name": z.string().describe("AI应用名称"),
    "url": z.string().describe("AI应用URL"),
    "description": z.string().describe("描述").optional(),
    "icon": z.string().describe("图标（Base64编码）").optional(),
    "category": z.string().describe("应用类别（字典值）"),
    "accessType": z.string().describe("访问权限类型"),
    "status": z.number().describe("发布状态：0-未发布，1-已发布").optional(),
  },
    async (params) => handleToolCall("create_ai_app", params),
  );

  server.tool(
    "update_ai_app",
    "更新AI应用",
    {
    "id": z.number(),
    "name": z.string().optional(),
    "url": z.string().optional(),
    "description": z.string().optional(),
    "icon": z.string().optional(),
    "category": z.string().optional(),
    "accessType": z.string().optional(),
  },
    async (params) => handleToolCall("update_ai_app", params),
  );

  server.tool(
    "delete_ai_app",
    "删除AI应用",
    {
    "id": z.number().describe("AI应用ID"),
  },
    async (params) => handleToolCall("delete_ai_app", params),
  );

  server.tool(
    "get_ai_app",
    "获取AI应用",
    {
    "id": z.number().describe("AI应用ID"),
  },
    async (params) => handleToolCall("get_ai_app", params),
  );

  server.tool(
    "get_ai_app_page",
    "获取AI应用分页（普通用户）",
    {
    "name": z.string().describe("AI应用名称").optional(),
    "status": z.number().describe("状态：0-未发布，1-已发布").optional(),
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_ai_app_page", params),
  );

  server.tool(
    "get_ai_app_manage_page",
    "获取AI应用管理分页（管理员）",
    {
    "name": z.string().describe("AI应用名称").optional(),
    "status": z.number().describe("状态：0-未发布，1-已发布").optional(),
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_ai_app_manage_page", params),
  );

  server.tool(
    "publish_ai_app",
    "发布AI应用",
    {
    "id": z.number().describe("AI应用ID"),
  },
    async (params) => handleToolCall("publish_ai_app", params),
  );

  server.tool(
    "unpublish_ai_app",
    "下架AI应用",
    {
    "id": z.number().describe("AI应用ID"),
  },
    async (params) => handleToolCall("unpublish_ai_app", params),
  );

  server.tool(
    "create_app",
    "创建应用",
    {
    "id": z.number().describe("主键ID（更新时必填）").optional(),
    "name": z.string().describe("应用名称"),
    "appType": z.string().describe("应用类型"),
    "version": z.string().describe("应用版本").optional(),
    "provider": z.string().describe("厂商/提供方").optional(),
    "description": z.string().optional(),
    "icon": z.string().describe("应用图标URL").optional(),
    "deployType": z.number().describe("部署方式"),
    "installGuide": z.string().describe("安装指导文档").optional(),
    "containerImage": z.string().describe("容器镜像").optional(),
    "startupScript": z.string().describe("启动脚本").optional(),
    "defaultResource": z.string().describe("默认资源配置").optional(),
    "scheduleStrategy": z.string().describe("调度策略").optional(),
  },
    async (params) => handleToolCall("create_app", params),
  );

  server.tool(
    "update_app",
    "更新应用",
    {
    "id": z.number().describe("主键ID（更新时必填）").optional(),
    "name": z.string().describe("应用名称"),
    "appType": z.string().describe("应用类型"),
    "version": z.string().describe("应用版本").optional(),
    "provider": z.string().describe("厂商/提供方").optional(),
    "description": z.string().optional(),
    "icon": z.string().describe("应用图标URL").optional(),
    "deployType": z.number().describe("部署方式"),
    "installGuide": z.string().describe("安装指导文档").optional(),
    "containerImage": z.string().describe("容器镜像").optional(),
    "startupScript": z.string().describe("启动脚本").optional(),
    "defaultResource": z.string().describe("默认资源配置").optional(),
    "scheduleStrategy": z.string().describe("调度策略").optional(),
  },
    async (params) => handleToolCall("update_app", params),
  );

  server.tool(
    "delete_app",
    "删除应用",
    {
    "id": z.number().describe("应用ID"),
  },
    async (params) => handleToolCall("delete_app", params),
  );

  server.tool(
    "get_app",
    "获取应用",
    {
    "id": z.number().describe("应用ID"),
  },
    async (params) => handleToolCall("get_app", params),
  );

  server.tool(
    "get_app_page",
    "获取应用分页",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_app_page", params),
  );

  server.tool(
    "get_app_list",
    "获取应用列表",
    {
    "name": z.string().describe("应用名称（支持模糊搜索）").optional(),
  },
    async (params) => handleToolCall("get_app_list", params),
  );

  server.tool(
    "publish_app",
    "发布应用",
    {
    "id": z.number().describe("应用ID"),
  },
    async (params) => handleToolCall("publish_app", params),
  );

  server.tool(
    "unpublish_app",
    "取消发布应用",
    {
    "id": z.number().describe("应用ID"),
  },
    async (params) => handleToolCall("unpublish_app", params),
  );

  server.tool(
    "get_routing_list",
    "获取路由策略列表",
    {},
    async (params) => handleToolCall("get_routing_list", params),
  );

  server.tool(
    "get_schedule_strategy_options",
    "获取调度策略选项列表",
    {},
    async (params) => handleToolCall("get_schedule_strategy_options", params),
  );

  server.tool(
    "deploy_instance",
    "部署应用实例",
    {
    "appId": z.number().describe("应用ID"),
    "routingId": z.number().describe("路由策略ID"),
    "instanceName": z.string().describe("实例名称"),
    "scheduleStrategy": z.string().describe("调度策略").optional(),
    "resourceSpec": z.string().describe("资源规格").optional(),
  },
    async (params) => handleToolCall("deploy_instance", params),
  );

  server.tool(
    "get_deploy_progress",
    "获取部署进度",
    {
    "taskId": z.string().describe("部署任务ID"),
  },
    async (params) => handleToolCall("get_deploy_progress", params),
  );

  server.tool(
    "get_instance_page",
    "获取应用实例分页列表",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_instance_page", params),
  );

  server.tool(
    "get_instance",
    "获取应用实例详情",
    {
    "id": z.number().describe("实例ID"),
  },
    async (params) => handleToolCall("get_instance", params),
  );

  server.tool(
    "start_instance",
    "启动应用实例",
    {
    "id": z.number().describe("实例ID"),
  },
    async (params) => handleToolCall("start_instance", params),
  );

  server.tool(
    "stop_instance",
    "停止应用实例",
    {
    "id": z.number().describe("实例ID"),
  },
    async (params) => handleToolCall("stop_instance", params),
  );

  server.tool(
    "restart_instance",
    "重启应用实例",
    {
    "id": z.number().describe("实例ID"),
  },
    async (params) => handleToolCall("restart_instance", params),
  );

  server.tool(
    "delete_instance",
    "删除应用实例",
    {
    "id": z.number().describe("实例ID"),
  },
    async (params) => handleToolCall("delete_instance", params),
  );

  server.tool(
    "get_instance_token",
    "获取应用实例访问Token",
    {
    "id": z.number().describe("实例ID"),
  },
    async (params) => handleToolCall("get_instance_token", params),
  );

  server.tool(
    "get_instance_logs",
    "获取应用实例日志",
    {
    "id": z.number().describe("实例ID"),
    "tail": z.number().describe("日志行数").optional(),
  },
    async (params) => handleToolCall("get_instance_logs", params),
  );

  server.tool(
    "get_instance_status_list",
    "批量查询应用实例状态",
    {
    "ids": z.array(z.any()).describe("实例ID集合"),
  },
    async (params) => handleToolCall("get_instance_status_list", params),
  );

  server.tool(
    "create_node",
    "创建节点",
    {
    "id": z.number().describe("主键ID（更新时必填）").optional(),
    "name": z.string().describe("节点名称"),
    "ipAddress": z.string().describe("IP地址"),
    "nodeType": z.number().describe("节点类型"),
    "deviceVendor": z.string().describe("设备厂商").optional(),
    "deviceModel": z.string().describe("设备型号").optional(),
    "gpuModel": z.string().describe("GPU型号").optional(),
    "gpuMemory": z.string().describe("GPU显存").optional(),
    "sshUsername": z.string().describe("SSH账号"),
    "sshPassword": z.string().describe("SSH密码"),
    "sshPort": z.number().describe("SSH端口").optional(),
  },
    async (params) => handleToolCall("create_node", params),
  );

  server.tool(
    "update_node",
    "更新节点",
    {
    "id": z.number(),
    "name": z.string().optional(),
    "ipAddress": z.string().optional(),
    "nodeType": z.number().optional(),
    "deviceVendor": z.string().optional(),
    "deviceModel": z.string().optional(),
    "gpuModel": z.string().optional(),
    "gpuMemory": z.string().optional(),
    "sshUsername": z.string().optional(),
    "sshPassword": z.string().optional(),
    "sshPort": z.number().optional(),
  },
    async (params) => handleToolCall("update_node", params),
  );

  server.tool(
    "delete_node",
    "删除节点",
    {
    "id": z.number().describe("节点ID"),
  },
    async (params) => handleToolCall("delete_node", params),
  );

  server.tool(
    "get_node",
    "获取节点",
    {
    "id": z.number().describe("节点ID"),
  },
    async (params) => handleToolCall("get_node", params),
  );

  server.tool(
    "get_node_page",
    "获取节点分页",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_node_page", params),
  );

  server.tool(
    "get_node_list",
    "获取节点列表",
    {},
    async (params) => handleToolCall("get_node_list", params),
  );

  server.tool(
    "restart_node",
    "重启节点",
    {
    "id": z.number().describe("节点ID"),
  },
    async (params) => handleToolCall("restart_node", params),
  );

  server.tool(
    "shutdown_node",
    "关机节点",
    {
    "id": z.number().describe("节点ID"),
  },
    async (params) => handleToolCall("shutdown_node", params),
  );

  server.tool(
    "get_node_usage",
    "批量查询节点使用率",
    {
    "body": z.array(z.any()).describe("节点ID列表"),
  },
    async (params) => handleToolCall("get_node_usage", params),
  );

  server.tool(
    "register_agent",
    "Agent注册",
    {
    "ip": z.string().describe("IP地址"),
    "isMain": z.boolean().describe("是否为主Agent节点").optional(),
  },
    async (params) => handleToolCall("register_agent", params),
  );

  server.tool(
    "get_network_interfaces",
    "查询宿主机网卡IP列表",
    {},
    async (params) => handleToolCall("get_network_interfaces", params),
  );

  server.tool(
    "get_observation_list",
    "查询调用记录列表",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
    "model": z.string().describe("调用模型筛选，多个用逗号分隔").optional(),
    "keyword": z.string().describe("关键词搜索").optional(),
    "startTime": z.string().describe("开始时间").optional(),
    "endTime": z.string().describe("结束时间").optional(),
    "orderBy": z.string().describe("排序字段").optional(),
    "orderDirection": z.string().describe("排序方向").optional(),
  },
    async (params) => handleToolCall("get_observation_list", params),
  );

  server.tool(
    "get_observation_detail",
    "查询调用链详情",
    {
    "observationId": z.string().describe("调用链ID"),
    "traceId": z.string().describe("Trace ID"),
  },
    async (params) => handleToolCall("get_observation_detail", params),
  );

  server.tool(
    "get_observation_models",
    "获取模型列表",
    {},
    async (params) => handleToolCall("get_observation_models", params),
  );

  server.tool(
    "get_platform_models",
    "获取平台模型列表",
    {},
    async (params) => handleToolCall("get_platform_models", params),
  );

  server.tool(
    "get_stats_cards",
    "获取统计卡片",
    {
    "dimension": z.string().describe("时间维度"),
  },
    async (params) => handleToolCall("get_stats_cards", params),
  );

  server.tool(
    "get_token_trend",
    "获取Token消耗趋势",
    {
    "dimension": z.string().describe("时间维度"),
  },
    async (params) => handleToolCall("get_token_trend", params),
  );

  server.tool(
    "get_cost_trend",
    "获取费用消耗趋势",
    {
    "dimension": z.string().describe("时间维度"),
  },
    async (params) => handleToolCall("get_cost_trend", params),
  );

  server.tool(
    "get_model_distribution",
    "获取模型使用分布",
    {
    "dimension": z.string().describe("时间维度"),
  },
    async (params) => handleToolCall("get_model_distribution", params),
  );

  server.tool(
    "get_org_distribution",
    "获取费用使用分布",
    {
    "dimension": z.string().describe("时间维度"),
  },
    async (params) => handleToolCall("get_org_distribution", params),
  );

  server.tool(
    "get_org_quota_top5",
    "获取组织配额使用TOP5",
    {
    "dimension": z.string().describe("时间维度"),
    "quotaType": z.string().describe("配额类型").optional(),
  },
    async (params) => handleToolCall("get_org_quota_top5", params),
  );

  server.tool(
    "get_user_quota_top5",
    "获取用户配额使用TOP5",
    {
    "dimension": z.string().describe("时间维度"),
    "quotaType": z.string().describe("配额类型").optional(),
  },
    async (params) => handleToolCall("get_user_quota_top5", params),
  );

  server.tool(
    "get_detail_table",
    "获取明细数据表",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_detail_table", params),
  );

  server.tool(
    "get_token_stats_cards",
    "获取Token统计卡片",
    {
    "dimension": z.string().describe("时间维度"),
  },
    async (params) => handleToolCall("get_token_stats_cards", params),
  );

  server.tool(
    "get_token_stats_trend",
    "获取Token消耗趋势",
    {
    "dimension": z.string().describe("时间维度"),
  },
    async (params) => handleToolCall("get_token_stats_trend", params),
  );

  server.tool(
    "get_token_model_distribution",
    "获取模型Token分布",
    {
    "dimension": z.string().describe("时间维度"),
    "type": z.string().describe("Token类型"),
  },
    async (params) => handleToolCall("get_token_model_distribution", params),
  );

  server.tool(
    "get_token_model_top5",
    "获取模型Token消耗TOP5",
    {
    "dimension": z.string().describe("时间维度"),
    "type": z.string().describe("Token类型"),
  },
    async (params) => handleToolCall("get_token_model_top5", params),
  );

  server.tool(
    "get_token_org_top5",
    "获取组织Token消耗TOP5",
    {
    "dimension": z.string().describe("时间维度"),
    "type": z.string().describe("Token类型"),
  },
    async (params) => handleToolCall("get_token_org_top5", params),
  );

  server.tool(
    "get_token_user_top5",
    "获取用户Token消耗TOP5",
    {
    "dimension": z.string().describe("时间维度"),
    "type": z.string().describe("Token类型"),
  },
    async (params) => handleToolCall("get_token_user_top5", params),
  );

  server.tool(
    "get_token_detail_table",
    "获取明细数据表",
    {
    "pageNo": z.number().describe("页码").optional(),
    "pageSize": z.number().describe("每页数量").optional(),
  },
    async (params) => handleToolCall("get_token_detail_table", params),
  );

  server.tool(
    "trigger_period_stats",
    "手动触发周期统计",
    {
    "periodMinutes": z.number().describe("周期分钟数").optional(),
  },
    async (params) => handleToolCall("trigger_period_stats", params),
  );

  server.tool(
    "trigger_cleanup",
    "手动触发数据清理",
    {},
    async (params) => handleToolCall("trigger_cleanup", params),
  );

  server.tool(
    "get_mcp_server_list",
    "获取MCP服务列表",
    {
    "ts": z.number().describe("时间戳"),
    "pageNum": z.number().describe("页码"),
    "pageSize": z.number().describe("每页数量"),
  },
    async (params) => handleToolCall("get_mcp_server_list", params),
  );

  server.tool(
    "get_mcp_server_detail",
    "获取MCP服务详情",
    {
    "serverName": z.string().describe("服务名称"),
    "ts": z.number().describe("时间戳"),
  },
    async (params) => handleToolCall("get_mcp_server_detail", params),
  );

}
