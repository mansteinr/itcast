module.exports = {
  apps: [
    {
      name: "tao-mcp-server",
      script: "src/index.ts",
      interpreter: "node",
      interpreter_args: "--import ./node_modules/tsx/dist/loader.mjs",
      env: {
        MCP_TRANSPORT: "streamable-http",
        MCP_PORT: "9988",
      },
      restart_delay: 3000,
      max_restarts: 10,
    },
  ],
};
