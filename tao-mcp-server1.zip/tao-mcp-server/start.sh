#!/bin/bash
# ============================================
# TAO MCP Server 启动脚本
# 
# 用法:
#   ./start.sh              # stdio 模式（本地调用）
#   ./start.sh http         # streamable-http 模式（远端部署）
#   ./start.sh http 4567    # 指定端口
# ============================================

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# 总是在目标平台重新安装依赖（避免 esbuild/tsx 等原生二进制跨平台不兼容）
echo "[tao-mcp-server] 安装/更新依赖..."
npm install --production --prefer-offline

# 加载 .env（如果存在）
if [ -f ".env" ]; then
  export $(grep -v '^#' .env | xargs)
fi

MODE="${1:-stdio}"
PORT="${2:-9988}"

echo "[tao-mcp-server] 启动模式: $MODE"

if [ "$MODE" = "http" ]; then
  echo "[tao-mcp-server] 监听端口: $PORT"
  echo "[tao-mcp-server] MCP 端点: http://0.0.0.0:$PORT/mcp"
  echo "[tao-mcp-server] 健康检查: http://0.0.0.0:$PORT/health"

  # 直接用 node + tsx loader 启动，避免 npx 链式进程在 nohup 下丢失
  nohup env MCP_TRANSPORT=streamable-http MCP_PORT="$PORT" \
    node --import ./node_modules/tsx/dist/loader.mjs src/index.ts \
    > logs/server.log 2>&1 &

  PID=$!
  echo "[tao-mcp-server] 后台已启动 (PID: $PID)"

  # 等待并验证启动
  sleep 2
  if curl -sf http://localhost:$PORT/health > /dev/null 2>&1; then
    echo "[tao-mcp-server] ✓ 启动成功，健康检查通过"
  else
    echo "[tao-mcp-server] ✗ 启动失败，查看日志: cat logs/server.log"
    cat logs/server.log
  fi
else
  echo "[tao-mcp-server] stdio 模式启动..."
  exec npx tsx src/index.ts
fi
